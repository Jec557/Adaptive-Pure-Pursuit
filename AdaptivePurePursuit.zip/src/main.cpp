/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "../include/common.h"
#include "../include/drivetrain.h"
#include "../include/odometry.h"

using namespace vex;

vex::task PurePursuit;


double leftwheelvelocity = 0;
double rightwheelvelocity = 0;

void SetWheelSpeed(double LSpeed, double RSpeed){
  const double PCT_TO_VOLT = 12.0 / 100.0;
  DriveTrain::LEFT.spin(fwd, (LSpeed * PCT_TO_VOLT)*27, volt);
  DriveTrain::RIGHT.spin(fwd, (RSpeed * PCT_TO_VOLT)*27, volt);  
}

int
Autonomous_Function(){
  while(Odometry::distance({Odometry::s_PositionX, Odometry::s_PositionY}, {-15, 121} /*The robot will end this path when it reaches a certain distance away from this point*/) > 8){
    std::vector<double> closest = Odometry::closestpoint(Odometry::smoothedPath1, Odometry::s_PositionX, Odometry::s_PositionY, Odometry::prevc);
  
    std::vector<double> trackedpoint = Odometry::lookaheadpoint(Odometry::smoothedPath1, Odometry::s_PositionX, Odometry::s_PositionY, Odometry::lookaheadd, Odometry::pfindex, 0, 0, 0);
  
    double signedcurve = Odometry::curveofarc(trackedpoint, Odometry::s_PositionX, Odometry::s_PositionY, Odometry::inertial_value, Odometry::lookaheadd);
  
    double leftwheelvelocity = Odometry::leftwheel(Odometry::smoothedPath1, Odometry::newvelocities1, closest, signedcurve, Odometry::width_of_robot);
  
    double rightwheelvelocity = Odometry::rightwheel(Odometry::smoothedPath1, Odometry::newvelocities1, closest, signedcurve, Odometry::width_of_robot);

    this_thread::sleep_for(20);
    SetWheelSpeed(leftwheelvelocity, rightwheelvelocity);

    /* Example of function you can put inside the Pure Pursuit funtion
    if(Odometry::distance({Odometry::s_PositionX, Odometry::s_PositionY}, {16, 100}) < 10){
      intake.spin(fwd, -9, volt);
      rfwing.open();
    }
      else{
        rfwing.close();
      }
    */
  }


  // You can even combine regular Drive straights and turns by inserting those functions inbetween the Pure Pursuit functions, for example here


  /* You can chain multiple pure pursuit paths together, just make sure Odometry::smoothedPath2 and Odometry::newvelocities2 corresponds to the correct number
  This is also an example of going backwards and using a different lookahead distance

  while(Odometry::distance({Odometry::s_PositionX, Odometry::s_PositionY}, {-46, 96}) > 10){
    std::vector<double> closest = Odometry::closestpoint(Odometry::smoothedPath2, Odometry::s_PositionX, Odometry::s_PositionY, Odometry::prevc);
  
    std::vector<double> trackedpoint = Odometry::lookaheadpoint(Odometry::smoothedPath2, Odometry::s_PositionX, Odometry::s_PositionY, 12, Odometry::pfindex, 0, 0, 0);
  
    double signedcurve = Odometry::curveofarc(trackedpoint, Odometry::s_PositionX, Odometry::s_PositionY, Odometry::Helpers::ToRadians(-(Inertial.rotation(deg) + 90)), 12);
  
    double rightwheelvelocity = -(Odometry::leftwheel(Odometry::smoothedPath2, Odometry::newvelocities2, closest, signedcurve, Odometry::width_of_robot));

    double leftwheelvelocity = -(Odometry::rightwheel(Odometry::smoothedPath2, Odometry::newvelocities2, closest, signedcurve, Odometry::width_of_robot));

    this_thread::sleep_for(20);
    SetWheelSpeed(leftwheelvelocity, rightwheelvelocity);

  }
*/
  return(0);
}

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  Inertial.startCalibration();
  while (Inertial.isCalibrating()){ // can take a while to finish calibration so we want to wait until it is ready(not needed anymore)
  }
  Inertial.resetRotation(); // we only reset the rotation at the beginning so we can use absolute position tracking
  
  DriveTrain::B1.resetPosition();
  // DriveTrain::M.resetPosition();

  Periodic::Register(Odometry::Periodic);

  Odometry::reset(0, 0, 0); // You can change the starting coordinates and inertial reading here

  Periodic::Initialize();


  // Set up callbacks for autonomous and driver control periods.
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {

  PurePursuit = vex::task(Autonomous_Function);
  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */              
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/


void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.
    //fourbar();
    vex::task::stop(Autonomous_Function);

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................
    Cntl.Screen.clearLine();
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//

int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);

  }
}