#pragma once

#include "common.h"

namespace DriveTrain{
/*****   PORTS WORK BABY   *****/
motor LF(PORT19, true); //top
motor LM(PORT18, true); // not true
motor LB(PORT17, true); //bottom
motor RF(PORT11); //top
motor RM(PORT12); //true
motor RB(PORT13); //bottom

motor_group LEFT(LF, LM, LB); 
motor_group RIGHT(RF, RM, RB);
motor_group DRIVETRAIN(LF, LM, LB, RF, RM, RB);

rotation B1(PORT3, true); // Back Wheel

} // namespace DriveTrain