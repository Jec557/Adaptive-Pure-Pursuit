#pragma once

#include "common.h"

#include "drivetrain.h"
#include <cmath>
#include <vector>
#include <iostream>
#include <algorithm>

namespace Odometry {

/*****************/
/*** CONSTANTS ***/
/*****************/

const static bool k_UseGyroscope = true;
static double ToRadians(double degrees) {return degrees * M_PI / 180.0;}

// SET VARIABLES HERE ***********************************************************************************************************
  
  //Odometry Variables
  // To measure this value, find the distance in inches between the left / right
  // wheels Basically like the diameter of the robot.
  const static double k_WheelToWheelDiameter = 10.25;
  const static double k_WheelRadius = 1.625;
  const static double k_BackWheelRadius = 2.75/2;
  const static double k_BackWheelDistanceFromCenter = 3.0;

  // Pure Pursuit Variables
  double weight_on_points = 0.1; // Increase this to make path follow set points more closely
  double weight_on_smoothness = 0.9; // Increase this to increase the smoothness of the path
  double tolerance = 0.001;
  double lookaheadd = 12; // Increase this to make the robot follow the path smoother, decrease to make the robot follow the path more closely
                          // You can also set this to a specific value for each path by replacing 'Odometry::lookaheadd' with a number of inches in the WheelVeolcities function in main.cpp
  double interval = 6.0; // Interval between injected waypoints
  double width_of_robot = 13.5; // In inches
  double inertial_value = ToRadians(-(Inertial.rotation(deg) - 90)); // This is for going forwards. If you want to go backwards, replace 'Odometry::inertial_value' with 'Odometry::Helpers::ToRadians(-(Inertial.rotation(deg) + 90))' in the WheelVeolcities function in main.cpp.
                                                                     // You will also need to set the leftwheelvelocity = -Odometry::rightwheel and rightwheelvelocity = -Odometry::leftwheel in the WheelVeolcities function in main.cpp
  double max_velocity = 600;
  double max_acceleration = 10;

/**************************************************************************************************************************/


// Function to calculate distance between two points
double distance(const std::vector<double>& a, const std::vector<double>& b) {
    return sqrt(pow((b[0] - a[0]), 2) + pow((b[1] - a[1]), 2));
}

// Function to inject waypoints at a regular interval between given waypoints
std::vector<std::vector<double>> injectWaypoints(const std::vector<std::vector<double>>& waypoints, double interval) {
    std::vector<std::vector<double>> injectedPoints;

    for (int i = 0; i < waypoints.size() - 1; ++i) {
        const std::vector<double>& startPoint = waypoints[i];
        const std::vector<double>& endPoint = waypoints[i + 1];

        double totalDistance = distance(startPoint, endPoint);
        int numIntervals = static_cast<int>(totalDistance / interval);

        for (int j = 0; j <= numIntervals; ++j) {
            double ratio = static_cast<double>(j + 1) / (numIntervals + 1);
            double newX = startPoint[0] + ratio * (endPoint[0] - startPoint[0]);
            double newY = startPoint[1] + ratio * (endPoint[1] - startPoint[1]);
            injectedPoints.push_back({newX, newY});
        }
    }

    return injectedPoints;
}

// Function to smooth points into a curve
std::vector<std::vector<double>> smoother(const std::vector<std::vector<double>>& path, double a, double b, double tolerance) {
    // Copy array
    std::vector<std::vector<double>> newPath = path;
    double change = tolerance;

    while (change >= tolerance) {
        change = 0.0;
        for (size_t i = 1; i < path.size() - 1; ++i) {
            for (size_t j = 0; j < path[i].size(); ++j) {
                double aux = newPath[i][j];
                newPath[i][j] += a * (path[i][j] - newPath[i][j]) + b *
                    (newPath[i - 1][j] + newPath[i + 1][j] - (2.0 * newPath[i][j]));
                change += std::abs(aux - newPath[i][j]);
            }
        }
    }

    return newPath;
}

// Function to calculate curvature of each point
std::vector<double> curve(const std::vector<std::vector<double>>& curvedpath){
    std::vector<double> curvaturepoints;
    curvaturepoints.insert(curvaturepoints.begin(), 0);
    for (int i = 1; i < curvedpath.size() - 1; ++i) {
        double x1 = curvedpath[i][0] + 0.001;
        double y1 = curvedpath[i][1];
        double x2 = curvedpath[i-1][0];
        double y2 = curvedpath[i-1][1];
        double x3 = curvedpath[i+1][0];
        double y3 = curvedpath[i+1][1];
        double k1 = 0.5 * (pow(x1, 2)+pow(y1, 2)-pow(x2, 2)-pow(y2, 2))/(x1-x2);
        double k2 = (y1-y2)/(x1-x2);
        double b = 0.5 * (pow(x2, 2) - 2*x2*k1 + pow(y2, 2) - pow(x3, 2) + 2*x3*k1 - pow(y3, 2))/(x3*k2 - y3 + y2 - x2*k2);
        double a = k1 - k2*b;
        double r = sqrt(pow((x1 - a), 2) + pow((y1 - b), 2));
        double curvature = 1/r;
        if (std::isnan(curvature) == true) {
            curvaturepoints.insert(curvaturepoints.end(), 0);
        } else {
            curvaturepoints.insert(curvaturepoints.end(), curvature);
        }
    }
    curvaturepoints.insert(curvaturepoints.end(), 0);
    return curvaturepoints;
}

std::vector<double> maxvelocities(const std::vector<double>& curvaturepts, double pathmaxvelocity){
    std::vector<double> maxvpoints;
    for (int i = 0; i < curvaturepts.size(); ++i) {
        maxvpoints.insert(maxvpoints.end(), std::min(pathmaxvelocity, 3/curvaturepts[i])); 
    }
    return maxvpoints;
}

// Function to calculate target velocities of each point
std::vector<double> targetvelocities(const std::vector<std::vector<double>>& smoothedpts, std::vector<double>& oldtargetv, double pathmaxacceleration){
    std::vector<double> newtargetv;
    newtargetv.insert(newtargetv.end(), 0);
    for (int i = smoothedpts.size() - 2; i >= 0; --i) {
        double dist = distance(smoothedpts[i+1], smoothedpts[i]);
        double vf = sqrt(pow(newtargetv[0], 2) + 2*pathmaxacceleration*dist);
        double newv = std::min(oldtargetv[i], vf);
        newtargetv.insert(newtargetv.begin(), newv); 
    }
    return newtargetv;
}

// Function to find closest point
std::vector<double> closestpoint(const std::vector<std::vector<double>>& smoothedpts, double x, double y, int prevclose){
    std::vector<double> closest = smoothedpts[0];
    for (int i = prevclose; i < smoothedpts.size(); ++i) {
        if(sqrt(pow((smoothedpts[i][0] - x), 2) + pow((smoothedpts[i][1] - y), 2)) < sqrt(pow((closest[0] - x), 2) + pow((closest[1] - y), 2))){
            closest = smoothedpts[i];
            prevclose = i;
        }
    }
    return closest;
}

double intersectionofcircle(double dx, double dy, double fx, double fy, double r){
    double a = pow(dx, 2) + pow(dy, 2);
    double b = 2 * (fx*dx + fy*dy);
    double c = pow(fx, 2) + pow(fy, 2) - r*r;
    double discriminant = b*b - 4*a*c;
    
    if (discriminant < 0) {
        // No intersection
        return -1;
    } else {
        discriminant = std::sqrt(discriminant);
        double t1 = (-b - discriminant)/(2*a);
        double t2 = (-b + discriminant)/(2*a);

        if (t1 >= 0 && t1 <= 1) {
            // Return t1 intersection
            return t1;
        }

        if (t2 >= 0 && t2 <= 1) {
            // Return t2 intersection
            return t2;
        }

        // Otherwise, no intersection
        return -1;
    }
}

// Function to find lookahead point
std::vector<double> lookaheadpoint(const std::vector<std::vector<double>>& smoothedpts, double x, double y, double lookaheaddist, double prevfindex, double newlookaheadpointx, double newlookaheadpointy, int prev){
    std::vector<double> newlookaheadpoint = {0, 0};
    for (int i = prev; i < smoothedpts.size() - 1; ++i) {
        double rayx = smoothedpts[i+1][0] - smoothedpts[i][0];
        double rayy = smoothedpts[i+1][1] - smoothedpts[i][1];
        double vecx = smoothedpts[i][0] - x;
        double vecy = smoothedpts[i][1] - y;
        double tvalue = intersectionofcircle(rayx, rayy, vecx, vecy, lookaheaddist);
        if(tvalue >= 0 && tvalue <= 1){
            double findex = i + tvalue;
            if(findex > prevfindex){
                prevfindex = findex;
                prev = i;
                newlookaheadpointx =  smoothedpts[i][0] + tvalue*rayx;
                newlookaheadpointy =  smoothedpts[i][1] + tvalue*rayy;
            }
        }
    }
    newlookaheadpoint = {newlookaheadpointx, newlookaheadpointy};
    return newlookaheadpoint;
}

double signum(double num){
    if(num >= 0){
        return 1;
    } else if (num == 0){
        return 0;
    } else{
        return -1;
    }
}

double curveofarc(const std::vector<double>& look, double x, double y, double robotangle, double lookaheaddist){
    double a = -tan(robotangle);
    double b = 1;
    double c = tan(robotangle)*x - y;
    double x1 = fabs(a*look[0] + b*look[1] + c)/sqrt(a*a + b*b);
    double curve = 2*x1/(lookaheaddist*lookaheaddist);
    double side = signum(sin(robotangle)*(look[0] - x) - cos(robotangle)*(look[1] - y));
    double signedcurvature = curve*side;
    return signedcurvature;
}

int getIndex(const std::vector<std::vector<double>>& v, const std::vector<double>& K) { 
    auto it = std::find(v.begin(), v.end(), K); 
    // If element was found 
    if (it != v.end())  
    { 
        // calculating the index 
        // of K 
        int index = it - v.begin(); 
        return index; 
    } 
    else { 
        // If the element is not 
        // present in the vector 
        return -1; 
    } 
} 

double previoustarget = 0;

// Rate Limiter (Prevents Unrealistic Acceleration)
double ratelimit(double previousoutput, double input, double max){
    if ((previousoutput - input) < -max){
        double output = previousoutput + max;
        previousoutput = output;
        return output;
    } else if ((previousoutput - input) > max){
        double output = previousoutput - max;
        previousoutput = output;
        return output;
    } else {
        previousoutput = input;
        return input;
    }
}

// Left Wheel Velocity
double leftwheel(const std::vector<std::vector<double>>& smoothedpts, const std::vector<double>& targets, const std::vector<double>& close, double curvature, double T){
    double index = getIndex(smoothedpts, close);
    double V = ratelimit(previoustarget, targets[index], 1.75);
    return V*(2 + curvature*T)/2;
}

// Right Wheel Velocity
double rightwheel(const std::vector<std::vector<double>>& smoothedpts, const std::vector<double>& targets, const std::vector<double>& close, double curvature, double T){
    double index = getIndex(smoothedpts, close);
    double V = ratelimit(previoustarget, targets[index], 1.75);
    return V*(2 - curvature*T)/2;
}


int prevc = 0;
double pfindex = 0;


/*************************/
/*** HELPERS / READERS ***/
/*************************/

namespace Helpers {

/*** UNIT CONVERSION HELPERS ***/
  static double ToDegrees(double radians) {return radians * 180.0 / M_PI;}

  static double ToRadians(double degrees) {return degrees * M_PI / 180.0;}

  static double LoopDegrees(double degrees){
    return degrees - 360.0 * round(degrees / 360.0);
  }

  /*** ENCODER READING HELPERS ***/
  static double GetRawLeftDistance(){
    double radians = ToRadians(DriveTrain::LM.position(deg) * 48/36);
    return k_WheelRadius * radians;
  }

  static double GetRawRightDistance(){
    double radians = ToRadians(DriveTrain::RM.position(deg) * 48/36);
    return k_WheelRadius * radians;
  }

  static double GetRawDistance(){
    return 0.858 * (GetRawLeftDistance() + GetRawRightDistance()); //*0.5
  }

  /*** HEADING READING HELPERS ***/
  static double GetRawGyroscopeHeading() {return -Inertial.rotation();}

  static double GetRawDrivetrainHeading(){
    return ToDegrees(GetRawRightDistance() - GetRawLeftDistance()) / k_WheelToWheelDiameter;
  }

  static double GetRawHeading(){
    if (k_UseGyroscope){
      return GetRawGyroscopeHeading();
    } else{
      return GetRawDrivetrainHeading();
    }
  }

  static double GetRawBackDistance(){
    double radians = ToRadians(DriveTrain::B1.position(deg));
    return k_BackWheelRadius * radians - (ToRadians(GetRawHeading()) * k_BackWheelDistanceFromCenter);
  }
} // namespace Helpers

/***********************/
/*** READING CHANGES ***/
/***********************/

namespace Changes{
  static double s_PreviousY = 0.0;
  static double GetYChange() {
    double y = Helpers::GetRawDistance();
    double change = y - s_PreviousY;
    s_PreviousY = y;

    return change;
  }

  static double s_PreviousX = 0.0;
  static double GetXChange() {
    double x = Helpers::GetRawBackDistance();
    double change = x - s_PreviousX;
    s_PreviousX = x;

    return change;
  }
} // namespace Changes

/**************************/
/*** ODOMETRY INTERFACE ***/
/**************************/

static double s_PositionX = 0.0;
static double s_PositionY = 0.0;
static double s_HeadingOffset = 0.0;

static void reset(double ix, double iy, double io){
  Changes::GetXChange();
  Changes::GetYChange();

  s_PositionX = ix;
  s_PositionY = iy;

  s_HeadingOffset = Helpers::GetRawHeading() - io;
}

static double GetHeadingDegrees(){
  return Helpers::GetRawHeading() - s_HeadingOffset;
}

static void Periodic(double dt){
  const double dX = Changes::GetXChange();
  const double dY = Changes::GetYChange();

  const double heading = Helpers::ToRadians(GetHeadingDegrees());

  const double co = cos(heading);
  const double so = sin(heading);

  s_PositionX += co * dX - so * dY;
  s_PositionY += co * dY + so * dX;

  PRINT_NUM(s_PositionX);
  PRINT_NUM(s_PositionY);
  PRINT_NUM(heading);
  PRINT_NUM(Inertial.rotation(deg));
  // PRINT_NUM(DriveTrain::B1.position(deg));
  // PRINT_NUM(DriveTrain::M.position(deg));
  PRINT_SEPARATOR;
  //Brain.Screen.print("X: ", s_PositionX);
  //Brain.Screen.print("Y: ", s_PositionY);
  //Brain.Screen.print("Orientation: ", heading);
}


static double GetX(){
  return s_PositionX;
}

static double GetY(){
  return s_PositionY;
}



/******************************/
/*** PURE PURSUIT INTERFACE ***/
/******************************/

std::vector<std::vector<double>> smoothedPath1 = {
  //Paste Coordinates of Path Here
};
std::vector<double> newvelocities1 = {//Paste Wheel Velocities Here
};

std::vector<std::vector<double>> smoothedPath2 = {
  //Paste Coordinates of Path Here
};
std::vector<double> newvelocities2 = {//Paste Wheel Velocities Here
};

std::vector<std::vector<double>> smoothedPath3 = {
  //Paste Coordinates of Path Here
};
    std::vector<double> newvelocities3 = {//Paste Wheel Velocities Here
};

}
