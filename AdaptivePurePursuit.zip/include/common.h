#pragma once

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "periodic.h"

using namespace vex;

// A global instance of competition
brain Brain;
competition Competition;

// define your global instances of motors and other devices here

controller Cntl;

inertial Inertial(PORT15);

#define PRINT_NUM(x) printf("[VAR] " #x " = %f\n", (double)(x));
#define PRINT_SEPARATOR printf("[==========]\n");