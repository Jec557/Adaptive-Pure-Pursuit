#pragma once

#include "common.h"

#include <vector>
#include <functional>

namespace Periodic {

  using PFunc = std::function<void(double)>;

  const static int k_UpdateMS = 20;

  static vex::mutex s_PeriodicMutex;
  static vex::thread s_PeriodicThread;
  static std::vector<PFunc> s_PeriodicList;

  static void Register(PFunc function) {
    s_PeriodicMutex.lock();

    s_PeriodicList.push_back(function);

    s_PeriodicMutex.unlock();
  }

  static int PeriodicCallback(void) {
    static vex::timer s_timer;

    while(true) {
      s_PeriodicMutex.lock();

      const double dt = s_timer.time(timeUnits::sec);
      s_timer.reset();

      for(PFunc& func : s_PeriodicList) {
        func(dt);
      }

      s_PeriodicMutex.unlock();

      wait(k_UpdateMS - int(s_timer.time(msec)), msec);
    }
  }

  static void Initialize() {
    s_PeriodicThread = vex::thread(PeriodicCallback);
  } 
}